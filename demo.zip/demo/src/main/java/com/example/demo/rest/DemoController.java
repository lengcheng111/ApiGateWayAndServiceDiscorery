package com.example.demo.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("products")
public class DemoController {
	
	@Autowired
	private Environment env;
	
	@PostMapping
	public String createProduct() {
		return "HTTP POST handler";
	}
	
	@GetMapping
	public String getProduct() {
		return "HTTP Get handler" + env.getProperty("local.server.port");
	}

}
