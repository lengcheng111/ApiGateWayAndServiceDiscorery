package com.microservices.demo.twitter.to.kafka.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TwitterToKafkaServiceApplicationTests {

    @Test
    public void contextLoad() {

    }
}
